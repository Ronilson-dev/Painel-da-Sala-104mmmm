import Sortable from "sortablejs";

const DAYS = [
  { key: "monday", label: "Seg" },
  { key: "tuesday", label: "Ter" },
  { key: "wednesday", label: "Qua" },
  { key: "thursday", label: "Qui" },
  { key: "friday", label: "Sex" }
];

const STORAGE_BASE = "weekly_activities_v1_user_";

const board = document.getElementById("board");
const addBtn = document.getElementById("addTask");
const newTaskText = document.getElementById("newTaskText");
const newTaskDay = document.getElementById("newTaskDay");
const clearAll = document.getElementById("clearAll");
const exportBtn = document.getElementById("export");

const loginOverlay = document.getElementById("loginOverlay");
const usernameInput = document.getElementById("usernameInput");
const loginBtn = document.getElementById("loginBtn");
const currentUserLabel = document.getElementById("currentUserLabel");
const logoutBtn = document.getElementById("logoutBtn");

let currentUser = null;
let data = emptyStructure();

// Boot
initAuth();
renderBoard();
attachControls();
initSortables();

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

function emptyStructure() {
  const obj = {};
  for (const d of DAYS) obj[d.key] = [];
  return obj;
}

/* --- Auth / per-user storage --- */
function initAuth(){
  const savedUser = localStorage.getItem(STORAGE_BASE + "last_user");
  if(savedUser){
    setUser(savedUser);
  } else {
    showLogin(true);
  }

  loginBtn.addEventListener("click", () => {
    const name = (usernameInput.value || "").trim();
    if(!name) return alert("Digite seu nome.");
    setUser(name);
    usernameInput.value = "";
    showLogin(false);
  });

  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem(STORAGE_BASE + "last_user");
    currentUser = null;
    data = emptyStructure();
    showLogin(true);
    renderBoard();
  });

  updateUserLabel();
}

function storageKeyForUser(user){
  return STORAGE_BASE + encodeURIComponent(user);
}

function setUser(user){
  currentUser = user;
  localStorage.setItem(STORAGE_BASE + "last_user", user);
  loadData();
  updateUserLabel();
  showLogin(false);
}

function showLogin(visible){
  if(visible){
    loginOverlay.style.display = "flex";
  } else {
    loginOverlay.style.display = "none";
  }
}

function updateUserLabel(){
  if(currentUser){
    currentUserLabel.textContent = `Aluno: ${currentUser}`;
    logoutBtn.style.display = "inline-block";
  } else {
    currentUserLabel.textContent = "";
    logoutBtn.style.display = "none";
  }
}

/* --- Data load/save --- */
function loadData(){
  try{
    if(!currentUser) return;
    const raw = localStorage.getItem(storageKeyForUser(currentUser));
    if(!raw) {
      data = emptyStructure();
      return;
    }
    const parsed = JSON.parse(raw);
    const base = emptyStructure();
    data = Object.assign(base, parsed);
  }catch(e){
    console.error(e);
    data = emptyStructure();
  }
}

function saveData(){
  if(!currentUser) return;
  localStorage.setItem(storageKeyForUser(currentUser), JSON.stringify(data));
  updateCounts();
}

/* --- Rendering --- */
function renderBoard(){
  board.innerHTML = "";
  for(const day of DAYS){
    const col = document.createElement("div");
    col.className = "column";
    col.dataset.day = day.key;

    const header = document.createElement("div");
    header.className = "colHeader";
    const h3 = document.createElement("h3");
    h3.textContent = day.label;
    const cnt = document.createElement("div");
    cnt.className = "count";
    cnt.dataset.countFor = day.key;
    header.appendChild(h3);
    header.appendChild(cnt);

    const list = document.createElement("div");
    list.className = "list";
    list.id = `list-${day.key}`;

    col.appendChild(header);
    col.appendChild(list);
    board.appendChild(col);

    // populate cards
    const items = data[day.key] || [];
    for(const item of items){
      list.appendChild(createCard(item));
    }
  }
  updateCounts();
  initSortables(); // re-init after rendering
}

function createCard(item){
  const card = document.createElement("div");
  card.className = "card";
  card.dataset.id = item.id;
  if(item.done) card.classList.add("done");

  const left = document.createElement("div");
  left.className = "left";

  const check = document.createElement("button");
  check.className = "check";
  check.title = "Marcar concluído";
  check.textContent = item.done ? "✓" : "";

  const titleWrap = document.createElement("div");
  titleWrap.style.display = "flex";
  titleWrap.style.flexDirection = "column";
  titleWrap.style.minWidth = "0";

  const title = document.createElement("div");
  title.className = "title";
  title.textContent = item.text;

  titleWrap.appendChild(title);

  // show observation only when not done and when present
  if(!item.done && item.note){
    const note = document.createElement("div");
    note.className = "note";
    note.textContent = item.note;
    titleWrap.appendChild(note);
  }

  left.appendChild(check);
  left.appendChild(titleWrap);

  const actions = document.createElement("div");
  actions.className = "actions";

  const edit = document.createElement("button");
  edit.className = "iconBtn";
  edit.title = "Editar";
  edit.textContent = "✎";

  const noteBtn = document.createElement("button");
  noteBtn.className = "iconBtn";
  noteBtn.title = "Adicionar/editar observação";
  noteBtn.textContent = "💬";

  const del = document.createElement("button");
  del.className = "iconBtn";
  del.title = "Excluir";
  del.textContent = "🗑";

  actions.appendChild(edit);
  actions.appendChild(noteBtn);
  actions.appendChild(del);

  card.appendChild(left);
  card.appendChild(actions);

  // event listeners
  check.addEventListener("click", () => {
    item.done = !item.done;
    if(item.done){
      check.textContent = "✓";
      card.classList.add("done");
    } else {
      check.textContent = "";
      card.classList.remove("done");
    }
    persistCard(item);
    renderBoard();
  });

  edit.addEventListener("click", () => {
    const newText = prompt("Editar atividade:", item.text);
    if(newText === null) return;
    item.text = newText.trim();
    if(item.text === ""){
      // delete if empty
      deleteCardById(item.id);
      return;
    }
    persistCard(item);
    renderBoard();
  });

  noteBtn.addEventListener("click", () => {
    const existing = item.note || "";
    const newNote = prompt("Observação (visível se não concluída):", existing);
    if(newNote === null) return;
    item.note = newNote.trim();
    if(item.note === "") delete item.note;
    persistCard(item);
    renderBoard();
  });

  del.addEventListener("click", () => {
    if(confirm("Remover esta atividade?")) deleteCardById(item.id);
  });

  // tap on title to edit
  title.addEventListener("click", () => {
    edit.click();
  });

  return card;
}

function persistCard(item){
  for(const d of DAYS){
    const idx = (data[d.key] || []).findIndex(x => x.id === item.id);
    if(idx !== -1){
      data[d.key][idx] = item;
      saveData();
      return;
    }
  }
}

function deleteCardById(id){
  for(const d of DAYS){
    const arr = data[d.key] || [];
    const idx = arr.findIndex(x => x.id === id);
    if(idx !== -1){
      arr.splice(idx,1);
      saveData();
      renderBoard();
      return;
    }
  }
}

function attachControls(){
  addBtn.addEventListener("click", () => {
    if(!currentUser) { alert("Identifique-se antes de adicionar atividades."); return; }
    const text = newTaskText.value.trim();
    if(!text) return;
    const day = newTaskDay.value;
    const item = { id: uid(), text, done:false, note:"" };
    data[day] = data[day] || [];
    data[day].push(item);
    newTaskText.value = "";
    saveData();
    renderBoard();
  });

  newTaskText.addEventListener("keydown", (e) => {
    if(e.key === "Enter") addBtn.click();
  });

  clearAll.addEventListener("click", () => {
    if(!currentUser) { alert("Identifique-se antes de limpar."); return; }
    if(!confirm("Apagar todas as atividades?")) return;
    data = emptyStructure();
    saveData();
    renderBoard();
  });

  exportBtn.addEventListener("click", () => {
    if(!currentUser) { alert("Identifique-se antes de exportar."); return; }
    const payload = JSON.stringify(data, null, 2);
    // Try to copy to clipboard
    if(navigator.clipboard){
      navigator.clipboard.writeText(payload).then(()=> {
        alert("Dados copiados para a área de transferência. Você pode compartilhar com seus colegas.");
      }).catch(()=> {
        prompt("Copie os dados abaixo:", payload);
      });
    } else {
      prompt("Copie os dados abaixo:", payload);
    }
  });
}

function updateCounts(){
  for(const d of DAYS){
    const el = document.querySelector(`[data-count-for="${d.key}"]`);
    const list = data[d.key] || [];
    el.textContent = `${list.length}`;
  }
}

/* Sortable (drag & drop between days + reorder). We use SortableJS from esm.sh */
function initSortables(){
  // avoid double-init: remove existing Sortable instances by clearing listeners and recreating
  const lists = DAYS.map(d => document.getElementById(`list-${d.key}`)).filter(Boolean);
  for(const list of lists){
    // create sortable
    Sortable.create(list, {
      group: "shared",
      animation: 150,
      fallbackOnBody: true,
      swapThreshold: 0.65,
      onAdd: function (evt) {
        handleDragEnd(evt);
      },
      onUpdate: function (evt) {
        handleDragEnd(evt);
      },
      onStart: function (evt) {
        evt.item.classList.add("dragging");
      },
      onEnd: function (evt) {
        evt.item.classList.remove("dragging");
      }
    });
  }
}

function handleDragEnd(evt){
  // After drag, rebuild arrays according to DOM
  const newData = emptyStructure();
  for(const d of DAYS){
    const listEl = document.getElementById(`list-${d.key}`);
    if(!listEl) continue;
    const children = Array.from(listEl.children);
    newData[d.key] = children.map(child => {
      const id = child.dataset.id;
      // find previous item by id
      for(const pd of DAYS){
        const found = (data[pd.key] || []).find(x => x.id === id);
        if(found) return found;
      }
      // fallback: create simple object
      return { id, text: child.textContent.trim(), done:false };
    });
  }
  data = newData;
  saveData();
  renderBoard();
}